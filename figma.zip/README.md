
  # Redesign Driver Dashboard Interface

  This is a code bundle for Redesign Driver Dashboard Interface. The original project is available at https://www.figma.com/design/tB3y4M4iB44ucOl4x6BXt6/Redesign-Driver-Dashboard-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  